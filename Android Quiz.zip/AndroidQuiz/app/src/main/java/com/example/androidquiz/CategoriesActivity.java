package com.example.androidquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;


public class CategoriesActivity extends AppCompatActivity {
    float score = 0.0f;
    private Button submitbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        submitbutton = findViewById(R.id.submit);
        submitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText etext = findViewById(R.id.ques8);
                String ans = etext.getText().toString();
                int Value = Integer.parseInt(ans);
                if (Value == 1)
                    score = score + 1;
                Intent scoreintent =new Intent(CategoriesActivity.this,ScoreActivity.class);
                scoreintent.putExtra("score",score);
                startActivity(scoreintent);
            }
        });

    }

    public void onradio1clicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        if (checked)
            score = score + 1;
    }

    public void onradio2clicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        if (checked)
            score = score + 1;
    }

    public void onradio3clicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        if (checked)
            score = score + 1;
    }

    public void onradio4clicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        if (checked)
            score = score + 1;
    }

    public void onradio5clicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        if (checked)
            score = score + 1;
    }

    public void oncheckbox6clicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        if (checked)
            score = (float) (score + 0.5);
    }

    public void oncheckbox7clicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        if (checked)
            score = (float) (score + 0.5);
    }

    public void onradio8clicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        if (checked)
            score = score + 1;
    }

    public void oncheckbox9clicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        if (checked)
            score = (float) (score + 0.5);
    }

    public void oncheckbox10clicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        if (checked)
            score = (float) (score + 0.5);
    }

    public void onradio11clicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        if (checked)
            score = score + 1;
    }

    public void onclickclear(View view) {
        score=0;
        RadioGroup radio1 = (RadioGroup) findViewById(R.id.groupradio1);
        radio1.clearCheck();
        RadioGroup radio2 = (RadioGroup) findViewById(R.id.groupradio2);
        radio2.clearCheck();
        RadioGroup radio3 = (RadioGroup) findViewById(R.id.groupradio3);
        radio3.clearCheck();
        RadioGroup radio4 = (RadioGroup) findViewById(R.id.groupradio4);
        radio4.clearCheck();
        RadioGroup radio5 = (RadioGroup) findViewById(R.id.groupradio5);
        radio5.clearCheck();
        RadioGroup radio7 = (RadioGroup) findViewById(R.id.groupradio7);
        radio7.clearCheck();
        RadioGroup radio10 = (RadioGroup) findViewById(R.id.groupradio10);
        radio10.clearCheck();
        CheckBox check6 = (CheckBox) findViewById(R.id.rad6_id1);
        if(check6.isChecked())
            check6.setChecked(false);
        CheckBox check7 = (CheckBox) findViewById(R.id.rad6_id2);
        if(check7.isChecked())
            check7.setChecked(false);
        CheckBox check8 = (CheckBox) findViewById(R.id.rad6_id3);
        if(check8.isChecked())
            check8.setChecked(false);
        CheckBox check9 = (CheckBox) findViewById(R.id.rad6_id4);
        if(check9.isChecked())
            check9.setChecked(false);
        CheckBox check10 = (CheckBox) findViewById(R.id.rad9_id1);
        if(check10.isChecked())
            check10.setChecked(false);
        CheckBox check11 = (CheckBox) findViewById(R.id.rad9_id2);
        if(check11.isChecked())
            check11.setChecked(false);
        CheckBox check12 = (CheckBox) findViewById(R.id.rad9_id3);
        if(check12.isChecked())
            check12.setChecked(false);
        CheckBox check13 = (CheckBox) findViewById(R.id.rad9_id4);
        if(check13.isChecked())
            check13.setChecked(false);
        EditText editText = (EditText) findViewById(R.id.ques8);
        editText.getText().clear();
        EditText editText1 = (EditText) findViewById(R.id.name);
        editText1.getText().clear();
    }
}