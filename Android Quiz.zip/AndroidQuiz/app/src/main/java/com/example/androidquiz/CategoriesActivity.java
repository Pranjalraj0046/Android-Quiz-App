package com.example.androidquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


public class CategoriesActivity extends AppCompatActivity {
    int score = 0;
    private Button submitbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        submitbutton = findViewById(R.id.submit);
        submitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText etext = findViewById(R.id.ques8);
                String ans = etext.getText().toString().trim();
                int value = 0;
                if(!TextUtils.isEmpty(ans)){
                    value = Integer.parseInt(ans);
                    if (value == 1) {
                        score = score + 1;
                    }
                }
                CheckQues1();
                CheckQues2();
                CheckQues3();
                CheckQues4();
                CheckQues5();
                CheckQues6();
                CheckQues7();
                CheckQues9();
                CheckQues10();
                EditText edtext = findViewById(R.id.name);
                String nam = edtext.getText().toString();
                Toast.makeText(getApplicationContext(), nam + " scored " + score + " marks" , Toast.LENGTH_LONG).show();
                Intent scoreintent =new Intent(CategoriesActivity.this,ScoreActivity.class);
                scoreintent.putExtra("score",score);
                startActivity(scoreintent);
            }
        });

    }

    public void CheckQues1() {
        RadioButton rad1 = (RadioButton) findViewById(R.id.rad1_id4);
        if (rad1.isChecked())
            score = score + 1;
        else
            score = score+0;
    }

    public void CheckQues2() {
        RadioButton rad2 = (RadioButton) findViewById(R.id.rad2_id4);
        if (rad2.isChecked())
            score = score + 1;
        else
            score = score+0;
    }

    public void CheckQues3() {
        RadioButton rad3 = (RadioButton) findViewById(R.id.rad3_id1);
        if (rad3.isChecked())
            score = score + 1;
        else
            score = score+0;
    }

    public void CheckQues4() {
        RadioButton rad4 = (RadioButton) findViewById(R.id.rad4_id3);
        if (rad4.isChecked())
            score = score + 1;
        else
            score = score+0;
    }

    public void CheckQues5() {
        RadioButton rad5 = (RadioButton) findViewById(R.id.rad5_id4);
        if (rad5.isChecked())
            score = score + 1;
        else
            score = score+0;
    }

    public void CheckQues6() {
        CheckBox opt1 = (CheckBox) findViewById(R.id.rad6_id1);
        CheckBox opt2 = (CheckBox) findViewById(R.id.rad6_id2);
        CheckBox opt3 = (CheckBox) findViewById(R.id.rad6_id3);
        CheckBox opt4 = (CheckBox) findViewById(R.id.rad6_id4);
        if (opt1.isChecked() && opt2.isChecked() && !opt3.isChecked() && !opt4.isChecked())
            score = score + 1;
        else
            score= score + 0;
    }


    public void CheckQues7() {
        RadioButton rad7 = (RadioButton) findViewById(R.id.rad7_id4);
        if (rad7.isChecked())
            score = score + 1;
        else
            score = score+0;
    }

    public void CheckQues9() {
        CheckBox opt1 = (CheckBox) findViewById(R.id.rad9_id1);
        CheckBox opt2 = (CheckBox) findViewById(R.id.rad9_id2);
        CheckBox opt3 = (CheckBox) findViewById(R.id.rad9_id3);
        CheckBox opt4 = (CheckBox) findViewById(R.id.rad9_id4);
        if (!opt1.isChecked() && opt2.isChecked() && opt3.isChecked() && !opt4.isChecked())
            score = score + 1;
        else
            score= score + 0;
    }

    public void CheckQues10() {
        RadioButton rad10 = (RadioButton) findViewById(R.id.rad10_id4);
        if (rad10.isChecked())
            score = score + 1;
        else
            score = score+0;
    }

    public void onclickclear(View view) {
        score=0;
        RadioGroup radio1 = (RadioGroup) findViewById(R.id.groupradio1);
        radio1.clearCheck();
        RadioGroup radio2 = (RadioGroup) findViewById(R.id.groupradio2);
        radio2.clearCheck();
        RadioGroup radio3 = (RadioGroup) findViewById(R.id.groupradio3);
        radio3.clearCheck();
        RadioGroup radio4 = (RadioGroup) findViewById(R.id.groupradio4);
        radio4.clearCheck();
        RadioGroup radio5 = (RadioGroup) findViewById(R.id.groupradio5);
        radio5.clearCheck();
        RadioGroup radio7 = (RadioGroup) findViewById(R.id.groupradio7);
        radio7.clearCheck();
        RadioGroup radio10 = (RadioGroup) findViewById(R.id.groupradio10);
        radio10.clearCheck();
        CheckBox check6 = (CheckBox) findViewById(R.id.rad6_id1);
        if(check6.isChecked())
            check6.setChecked(false);
        CheckBox check7 = (CheckBox) findViewById(R.id.rad6_id2);
        if(check7.isChecked())
            check7.setChecked(false);
        CheckBox check8 = (CheckBox) findViewById(R.id.rad6_id3);
        if(check8.isChecked())
            check8.setChecked(false);
        CheckBox check9 = (CheckBox) findViewById(R.id.rad6_id4);
        if(check9.isChecked())
            check9.setChecked(false);
        CheckBox check10 = (CheckBox) findViewById(R.id.rad9_id1);
        if(check10.isChecked())
            check10.setChecked(false);
        CheckBox check11 = (CheckBox) findViewById(R.id.rad9_id2);
        if(check11.isChecked())
            check11.setChecked(false);
        CheckBox check12 = (CheckBox) findViewById(R.id.rad9_id3);
        if(check12.isChecked())
            check12.setChecked(false);
        CheckBox check13 = (CheckBox) findViewById(R.id.rad9_id4);
        if(check13.isChecked())
            check13.setChecked(false);
        EditText editText = (EditText) findViewById(R.id.ques8);
        editText.getText().clear();
        EditText editText1 = (EditText) findViewById(R.id.name);
        editText1.getText().clear();
    }

}